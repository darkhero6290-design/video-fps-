package com.fpsanalyzer.app

import android.net.Uri
import android.os.Bundle
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvFps: TextView
    private lateinit var tvFpsMode: TextView
    private lateinit var tvTotalFrames: TextView
    private lateinit var tvDuration: TextView
    private lateinit var tvResolution: TextView
    private lateinit var tvCodec: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnSelectVideo: Button
    private lateinit var cardResults: View

    private val selectVideoLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            analyzeVideo(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvFps = findViewById(R.id.tvFps)
        tvFpsMode = findViewById(R.id.tvFpsMode)
        tvTotalFrames = findViewById(R.id.tvTotalFrames)
        tvDuration = findViewById(R.id.tvDuration)
        tvResolution = findViewById(R.id.tvResolution)
        tvCodec = findViewById(R.id.tvCodec)
        progressBar = findViewById(R.id.progressBar)
        btnSelectVideo = findViewById(R.id.btnSelectVideo)
        cardResults = findViewById(R.id.cardResults)

        btnSelectVideo.setOnClickListener {
            selectVideoLauncher.launch("video/*")
        }
    }

    private fun analyzeVideo(uri: Uri) {
        progressBar.visibility = View.VISIBLE
        btnSelectVideo.isEnabled = false
        tvStatus.text = "Analizando fotogramas con MediaExtractor..."

        lifecycleScope.launch(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            val extractor = MediaExtractor()

            try {
                retriever.setDataSource(applicationContext, uri)
                extractor.setDataSource(applicationContext, uri, null)

                // Encontrar pista de vídeo
                var videoTrackIndex = -1
                var videoFormat: MediaFormat? = null

                for (i in 0 until extractor.trackCount) {
                    val format = extractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("video/")) {
                        videoTrackIndex = i
                        videoFormat = format
                        break
                    }
                }

                if (videoTrackIndex == -1 || videoFormat == null) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, "No se encontró pista de vídeo válida", Toast.LENGTH_LONG).show()
                        progressBar.visibility = View.GONE
                        btnSelectVideo.isEnabled = true
                    }
                    return@launch
                }

                extractor.selectTrack(videoTrackIndex)

                // Extraer metadatos
                val width = videoFormat.getInteger(MediaFormat.KEY_WIDTH)
                val height = videoFormat.getInteger(MediaFormat.KEY_HEIGHT)
                val mime = videoFormat.getString(MediaFormat.KEY_MIME) ?: "Desconocido"

                val durationUs = try {
                    videoFormat.getLong(MediaFormat.KEY_DURATION)
                } catch (e: Exception) {
                    val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    (durStr?.toLongOrNull() ?: 0L) * 1000L
                }

                val durationSec = durationUs / 1_000_000.0

                // Recorrer los timestamps de fotogramas reales
                var frameCount = 0
                var lastSampleTimeUs = -1L
                val deltasUs = mutableListOf<Long>()

                while (extractor.sampleTime != -1L) {
                    val currentTimeUs = extractor.sampleTime
                    if (lastSampleTimeUs != -1L) {
                        val delta = currentTimeUs - lastSampleTimeUs
                        if (delta > 0) {
                            deltasUs.add(delta)
                        }
                    }
                    lastSampleTimeUs = currentTimeUs
                    frameCount++
                    extractor.advance()
                }

                val realFps = if (durationSec > 0) frameCount / durationSec else 0.0

                // Evaluar CFR vs VFR
                var isCfr = true
                if (deltasUs.size > 2) {
                    val avgDelta = deltasUs.average()
                    val threshold = avgDelta * 0.05 // 5% de tolerancia
                    val outliers = deltasUs.count { abs(it - avgDelta) > threshold }
                    if (outliers.toDouble() / deltasUs.size > 0.05) {
                        isCfr = false
                    }
                }

                val durationFormatted = formatDuration(durationSec)

                withContext(Dispatchers.Main) {
                    tvFps.text = String.format(Locale.US, "%.3f FPS", realFps)
                    tvFpsMode.text = if (isCfr) "CFR (Frecuencia Constante)" else "VFR (Frecuencia Variable)"
                    tvTotalFrames.text = String.format(Locale.US, "%,d fotogramas", frameCount)
                    tvDuration.text = durationFormatted
                    tvResolution.text = "${width} x ${height}"
                    tvCodec.text = mime.removePrefix("video/").uppercase()

                    progressBar.visibility = View.GONE
                    cardResults.visibility = View.VISIBLE
                    btnSelectVideo.isEnabled = true
                    tvStatus.text = "Análisis completado exitosamente"
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Error al analizar: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    progressBar.visibility = View.GONE
                    btnSelectVideo.isEnabled = true
                }
            } finally {
                retriever.release()
                extractor.release()
            }
        }
    }

    private fun formatDuration(seconds: Double): String {
        val totalSec = seconds.toInt()
        val hrs = totalSec / 3600
        val mins = (totalSec % 3600) / 60
        val secs = totalSec % 60
        val ms = ((seconds - totalSec) * 1000).roundToInt()
        return String.format(Locale.US, "%02d:%02d:%02d.%03d", hrs, mins, secs, ms)
    }
}
