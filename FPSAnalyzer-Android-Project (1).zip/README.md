# FPS Analyzer - Proyecto Android Completo + GitHub Actions

Este archivo contiene el proyecto nativo listo para compilar en Android Studio o generar el APK con GitHub Actions de forma 100% gratuita y automática.

## Opción 1: Generar el APK en 2 minutos con GitHub Actions (Recomendada)
1. Ve a GitHub y crea un nuevo repositorio privado o público (por ejemplo: `fps-analyzer`).
2. Sube los archivos de este ZIP a tu repositorio (o sube este archivo con el nombre `FPSAnalyzer-Android-Project.zip`).
3. Ve a la pestaña **Actions** en tu repositorio de GitHub.
4. Selecciona el workflow **"Build FPS Analyzer APK"** y pulsa **"Run workflow"**.
5. Cuando finalice (tarda aprox. 2 minutos), descarga el archivo en **Artifacts**: `FPS-Analyzer-APK.zip` que contiene el instalable `app-debug.apk` listo para instalar en tu Moto G30 o cualquier Android.

## Opción 2: Abrir en Android Studio
1. Descomprime la carpeta `FPSAnalyzer`.
2. Abre Android Studio -> **File** -> **Open...** y selecciona la carpeta `FPSAnalyzer`.
3. Conecta tu teléfono Android o emulador y haz clic en **Run** (o ejecuta en terminal `./gradlew assembleDebug`).
